<?php
return array(
    /*'switch'=>array(//配置在表单中的键名 ,这个会是config[random]
        'title'=>'是否使用',//表单的文字
        'type'=>'radio',         //表单的类型：text、textarea、checkbox、radio、select等
        'options'=>array(        //select 和radion、checkbox的子选项
            '1'=>'使用',       //值=>文字
            '0'=>'不使用',
        ),
        'value'=>'1',            //表单的默认值
    ),*/
    'records' => array(
        'title' => '每页记录数',
        'type' => 'text',
        'value' => '5',
    ),
);
                                