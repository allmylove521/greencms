<?php
/**
 * Created by PhpStorm.
 * User: TianShuo
 * Date: 14-5-20
 * Time: 下午8:00
 * 一切为了学生,为了一切学生,为了学生一切
 */
function hello_world()
{
    dump("自定义函数test");
}


