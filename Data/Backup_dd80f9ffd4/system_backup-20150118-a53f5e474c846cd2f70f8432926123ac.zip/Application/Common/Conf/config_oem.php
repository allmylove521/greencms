<?php
/**
 * OEM 版本屏蔽左侧菜单
 * User: Timothy Zhang
 * Date: 14-9-24
 * Time: 下午9:20
 */

return array(
    //'配置项'=>'配置值'


    $menu_black_list = array(
        'System'=> array(
            'System/bugs' => 'Bug反馈',
        )
    )






);