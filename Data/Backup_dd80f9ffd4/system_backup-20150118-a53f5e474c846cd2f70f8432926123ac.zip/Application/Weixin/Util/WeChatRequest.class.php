<?php
/**
 * Created by PhpStorm.
 * User: Timothy Zhang
 * Date: 14-10-25
 * Time: 下午11:16
 */

namespace Weixin\Util;


class WeChatRequest {

} 