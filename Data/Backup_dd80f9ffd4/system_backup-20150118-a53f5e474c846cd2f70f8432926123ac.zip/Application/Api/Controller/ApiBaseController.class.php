<?php
/**
 * Created by GreenStudio GCS Dev Team.
 * File: ApiBaseController.class.php
 * User: Timothy Zhang
 * Date: 14-4-22
 * Time: 下午5:59
 */
/**
 * Created by GreenStudio GCS Dev Team.
 * File: ApiBaseController.class.php
 * User: Timothy Zhang
 * Date: 14-4-22
 * Time: 下午5:59
 */
namespace Api\Controller;

use Common\Controller\BaseController;


class ApiBaseController extends BaseController
{


}