<?php
/**
 * Created by GreenStudio GCS Dev Team.
 * File: AccessModel.class.php
 * User: Timothy Zhang
 * Date: 14-1-26
 * Time: 下午7:26
 */

namespace Admin\Model;

use Think\Model\RelationModel;

/**
 * Class AccessModel
 * @package Admin\Model
 */
class AccessModel extends RelationModel
{

}